package com.renea.psicologiauv.gui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.renea.psicologiauv.R
import com.renea.psicologiauv.data.ImportadorNotas
import com.renea.psicologiauv.data.ImprimirPDF
import com.renea.psicologiauv.data.Serializador
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream


/**
 * Variante de OpenDocument que además le sugiere al selector de archivos
 * del sistema abrir directamente en [uriInicial].
 */
private class AbrirDocumentoEnCarpeta(
    private val uriInicial: Uri?
) : ActivityResultContracts.OpenDocument() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun createIntent(
        context: Context,
        input: Array<String>
    ): Intent {

        val intent =
            super.createIntent(
                context,
                input
            )

        if (uriInicial != null) {

            intent.putExtra(
                DocumentsContract.EXTRA_INITIAL_URI,
                uriInicial
            )
        }

        return intent
    }
}


/* ---------------------------------------------------------------------- */
/* ACCESOS RÁPIDOS                                                        */
/* ---------------------------------------------------------------------- */

private const val ENLACE_RESOLUCION_091 =
    "https://drive.google.com/file/d/1ke6EwQoExMTVH0PAq-CVV8dtOjzwkx_K/view?usp=drive_link"

private const val ENLACE_ACUERDO_009 =
    "https://registro.univalle.edu.co/wp-content/uploads/2024/05/acuerdo_009.pdf"

private const val ENLACE_MALLA_CURRICULAR =
    "https://drive.google.com/file/d/1oagbDquPWx4ggXu8yNtEyGnigYpgMr6r/view?usp=sharing"

private const val ENLACE_SIRA =
    "https://sira1.univalle.edu.co/sra/"

private const val CORREO_REPRESENTANTE_FACULTAD =
    "representante.facultad@correounivalle.edu.co"

private const val CORREO_DIRECCION_PROGRAMA =
    "pregrado.psicologia@correounivalle.edu.co"


/**
 * Abre [url] en el navegador.
 */
private fun abrirEnlace(
    contexto: Context,
    url: String
) {

    try {

        contexto.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse(url)
            )
        )

    } catch (e: Exception) {

        Log.e(
            "PsicologiaUV",
            "Error abriendo enlace",
            e
        )

        Toast.makeText(
            contexto,
            "No se pudo abrir el enlace.",
            Toast.LENGTH_LONG
        ).show()
    }
}


/**
 * Abre la app de correo con [correo] como destinatario.
 */
private fun abrirCorreo(
    contexto: Context,
    correo: String
) {

    try {

        contexto.startActivity(
            Intent(
                Intent.ACTION_SENDTO,
                Uri.parse("mailto:$correo")
            )
        )

    } catch (e: Exception) {

        Log.e(
            "PsicologiaUV",
            "Error abriendo app de correo",
            e
        )

        Toast.makeText(
            contexto,
            "No hay ninguna app de correo instalada.",
            Toast.LENGTH_LONG
        ).show()
    }
}


/**
 * Ícono circular con su leyenda centrada debajo.
 */
@Composable
private fun AccesoRapido(
    icono: Int,
    leyenda: String,
    onClick: () -> Unit
) {

    Column(
        horizontalAlignment =
            Alignment.CenterHorizontally,

        modifier =
            Modifier.width(60.dp)
    ) {

        Surface(
            shape = CircleShape,

            color =
                MaterialTheme
                    .colorScheme
                    .primary,

            modifier =
                Modifier
                    .size(48.dp)
                    .clickable(
                        onClick = onClick
                    )
        ) {

            Box(
                contentAlignment =
                    Alignment.Center
            ) {

                Icon(
                    painter =
                        painterResource(icono),

                    contentDescription =
                        leyenda,

                    tint =
                        MaterialTheme
                            .colorScheme
                            .onPrimary,

                    modifier =
                        Modifier.size(22.dp)
                )
            }
        }

        Spacer(
            Modifier.height(4.dp)
        )

        Text(
            text = leyenda,

            style =
                MaterialTheme
                    .typography
                    .labelSmall,

            textAlign =
                TextAlign.Center,

            maxLines = 2
        )
    }
}


/* ---------------------------------------------------------------------- */
/* EDITAR - datos del estudiante                                          */
/* ---------------------------------------------------------------------- */

@Composable
fun PantallaEditar(
    modifier: Modifier = Modifier,
    viewModel: ControlV
) {

    val estudiante =
        viewModel.programa.estudiante
            ?: return

    val contexto =
        LocalContext.current

    /*
     * ------------------------------------------------------------------
     * ELIMINAR ESTUDIANTE (botón de la papelera)
     * ------------------------------------------------------------------
     */

    var mostrarConfirmacionEliminar by remember {
        mutableStateOf(false)
    }


    /*
     * ------------------------------------------------------------------
     * DATOS PERSONALES
     * ------------------------------------------------------------------
     */

    var nombre by remember(
        estudiante.nombre
    ) {

        mutableStateOf(
            estudiante.nombre
        )
    }


    var codigoTexto by remember(
        estudiante.codigo
    ) {

        mutableStateOf(
            estudiante.codigo.toString()
        )
    }


    val datosModificados =
        nombre != estudiante.nombre ||
                codigoTexto != estudiante.codigo.toString()


    /*
     * ------------------------------------------------------------------
     * AVATAR
     * ------------------------------------------------------------------
     */

    val avatarBitmap =
        remember(
            estudiante.avatarUri
        ) {

            estudiante.avatarUri?.let { ruta ->

                BitmapFactory
                    .decodeFile(ruta)
                    ?.asImageBitmap()
            }
        }


    /*
     * ------------------------------------------------------------------
     * SELECTOR DE IMAGEN
     * ------------------------------------------------------------------
     */

    val selectorImagen =
        rememberLauncherForActivityResult(

            contract =
                ActivityResultContracts
                    .PickVisualMedia()

        ) { uri ->

            if (uri != null) {

                try {

                    val archivoAvatar =
                        File(
                            contexto.filesDir,
                            "avatar_${estudiante.codigo}.jpg"
                        )

                    contexto.contentResolver
                        .openInputStream(uri)
                        ?.use { entrada ->

                            FileOutputStream(
                                archivoAvatar
                            ).use { salida ->

                                entrada.copyTo(
                                    salida
                                )
                            }
                        }

                    viewModel
                        .cambiarAvatarEstudiante(
                            archivoAvatar.absolutePath
                        )

                } catch (e: Exception) {

                    Toast.makeText(
                        contexto,
                        "No se pudo cargar la imagen seleccionada.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }


    /*
     * ------------------------------------------------------------------
     * IMPORTAR / EXPORTAR DATOS
     * ------------------------------------------------------------------
     */

    val serializador =
        remember(contexto) {

            Serializador(
                contexto
            )
        }


    val importadorNotas =
        remember(contexto) {

            ImportadorNotas(
                contexto
            )
        }


    val alcanceCorrutinas =
        rememberCoroutineScope()


    /*
     * ------------------------------------------------------------------
     * GENERAR INFORME PDF
     * ------------------------------------------------------------------
     */

    fun generarYAbrirInformePdf() {

        alcanceCorrutinas.launch {

            try {

                Toast.makeText(
                    contexto,
                    "Generando PDF...",
                    Toast.LENGTH_SHORT
                ).show()

                val uri =
                    withContext(
                        Dispatchers.IO
                    ) {

                        val imprimirPDF =
                            ImprimirPDF(
                                contexto
                            )

                        imprimirPDF.generarYGuardar(
                            viewModel.programa
                        )
                    }

                if (uri != null) {

                    withContext(
                        Dispatchers.Main
                    ) {

                        ImprimirPDF(
                            contexto
                        ).abrirPDF(
                            uri
                        )
                    }

                } else {

                    withContext(
                        Dispatchers.Main
                    ) {

                        Toast.makeText(
                            contexto,
                            "No se pudo generar el PDF. Verifica que tengas permisos de escritura.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            } catch (e: Exception) {

                Log.e(
                    "PsicologiaUV",
                    "Error generando el PDF",
                    e
                )

                withContext(
                    Dispatchers.Main
                ) {

                    Toast.makeText(
                        contexto,
                        "Error al generar el PDF: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }


    /*
     * ------------------------------------------------------------------
     * PERMISO DE ALMACENAMIENTO
     * ------------------------------------------------------------------
     */

    val permisoAlmacenamiento =
        rememberLauncherForActivityResult(

            contract =
                ActivityResultContracts
                    .RequestPermission()

        ) { concedido ->

            if (concedido) {

                generarYAbrirInformePdf()

            } else {

                Toast.makeText(
                    contexto,
                    "No se puede generar el PDF sin permiso de escritura en el almacenamiento.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }


    /*
     * ------------------------------------------------------------------
     * SELECTOR PDF DE NOTAS
     * ------------------------------------------------------------------
     */

    val selectorPdfNotas =
        rememberLauncherForActivityResult(

            contract =
                remember(contexto) {

                    AbrirDocumentoEnCarpeta(
                        serializador
                            .uriCarpetaDescargas()
                    )
                }

        ) { uri ->

            if (uri != null) {

                alcanceCorrutinas.launch {

                    val resultado =
                        try {

                            withContext(
                                Dispatchers.IO
                            ) {

                                val texto =
                                    importadorNotas
                                        .extraerTexto(
                                            uri
                                        )

                                val codigosConocidos =
                                    estudiante
                                        .asignaturas
                                        .map {
                                            it.codigo
                                        }

                                importadorNotas
                                    .extraerNotasPorCodigo(
                                        texto,
                                        codigosConocidos
                                    )
                            }

                        } catch (e: Exception) {

                            Log.e(
                                "PsicologiaUV",
                                "Error leyendo el PDF de notas",
                                e
                            )

                            null
                        }


                    if (resultado == null) {

                        Toast.makeText(
                            contexto,
                            "No se pudo leer el PDF seleccionado.",
                            Toast.LENGTH_LONG
                        ).show()

                    } else if (resultado.isEmpty()) {

                        Toast.makeText(
                            contexto,
                            "No se encontró ninguna materia del pénsum en ese PDF.",
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        val actualizadas =
                            viewModel
                                .importarNotasDesdePdf(
                                    resultado
                                )

                        Toast.makeText(
                            contexto,
                            "Se importaron $actualizadas nota(s) desde el PDF. Recuerda actualizar el semestre de las asignaturas que lo requieran.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }


    /*
     * ------------------------------------------------------------------
     * SELECTOR JSON
     * ------------------------------------------------------------------
     */

    val selectorJsonImportar =
        rememberLauncherForActivityResult(

            contract =
                remember(contexto) {

                    AbrirDocumentoEnCarpeta(
                        serializador
                            .uriCarpetaDescargas()
                    )
                }

        ) { uri ->

            if (uri != null) {

                alcanceCorrutinas.launch {

                    val nuevoEstudiante =
                        withContext(
                            Dispatchers.IO
                        ) {

                            serializador
                                .importarEstudianteDesdeUri(
                                    uri
                                )
                        }


                    if (nuevoEstudiante != null) {

                        viewModel
                            .importarEstudianteDesdeJson(
                                nuevoEstudiante
                            )

                        Toast.makeText(
                            contexto,
                            "Datos importados desde el JSON seleccionado.",
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        Toast.makeText(
                            contexto,
                            "El archivo elegido no es un JSON de estudiante válido.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }


    /*
     * ------------------------------------------------------------------
     * INTERFAZ
     * ------------------------------------------------------------------
     */

    Box(
        modifier =
            modifier.fillMaxSize()
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(
                        rememberScrollState()
                    )
        ) {


            /*
             * ==============================================================
             * AVATAR (toca la foto para cambiarla)
             * ==============================================================
             */

            Box(
                modifier =
                    Modifier.fillMaxWidth(),

                contentAlignment =
                    Alignment.Center
            ) {

                Box(
                    modifier =
                        Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                            .border(
                                2.dp,
                                MaterialTheme.colorScheme.primary,
                                CircleShape
                            )
                            .clickable {

                                selectorImagen.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts
                                            .PickVisualMedia
                                            .ImageOnly
                                    )
                                )
                            },

                    contentAlignment =
                        Alignment.Center
                ) {

                    if (avatarBitmap != null) {

                        Image(
                            bitmap = avatarBitmap,
                            contentDescription = "Foto de perfil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                    } else {

                        Image(
                            painter =
                                painterResource(
                                    R.drawable.ic_avatar_default
                                ),
                            contentDescription = "Foto de perfil",
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(16.dp)
                        )
                    }
                }
            }

            Spacer(
                Modifier.height(6.dp)
            )

            Text(
                text = "Toca la foto para cambiarla",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                Modifier.height(20.dp)
            )


            /*
             * ==============================================================
             * NOMBRE Y CÓDIGO (editables)
             * ==============================================================
             */

            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                Modifier.height(8.dp)
            )




            /*
             * ==============================================================
             * GUARDAR DATOS PERSONALES
             * ==============================================================
             */

            if (datosModificados) {

                Spacer(
                    Modifier.height(8.dp)
                )

                Button(

                    onClick = {

                        viewModel
                            .cambiarNombreEstudiante(
                                nombre
                            )

                        codigoTexto
                            .toIntOrNull()
                            ?.let {

                                viewModel
                                    .cambiarCodigoEstudiante(
                                        it
                                    )
                            }
                    }

                ) {

                    Text(
                        "Guardar datos personales"
                    )
                }
            }


            Spacer(
                Modifier.height(24.dp)
            )


            HorizontalDivider()


            Spacer(
                Modifier.height(16.dp)
            )


            /*
             * ==============================================================
             * 1. LÍNEA PROFESIONAL
             * ==============================================================
             */

            Text(
                "Línea profesional",

                style =
                    MaterialTheme
                        .typography
                        .titleLarge
            )


            Spacer(
                Modifier.height(8.dp)
            )


            var editandoLinea by remember(
                estudiante.linea
            ) {

                mutableStateOf(
                    estudiante.linea == "Ninguna"
                )
            }


            if (editandoLinea) {

                Text(
                    "Selecciona tu línea:"
                )


                Spacer(
                    Modifier.height(7.dp)
                )


                listOf(
                    "Educativa",
                    "Social",
                    "Organizacional",
                    "Clínica",
                    "NeuroClínica"
                ).forEach { linea ->

                    OutlinedButton(

                        onClick = {

                            viewModel
                                .cambiarLineaEstudiante(
                                    linea
                                )

                            editandoLinea = false
                        },

                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 4.dp
                                )
                    ) {

                        Text(
                            linea
                        )
                    }
                }

            } else {

                Row(

                    verticalAlignment =
                        Alignment.CenterVertically,

                    modifier =
                        Modifier.fillMaxWidth()
                ) {

                    Text(

                        "Línea actual: ${estudiante.linea}",

                        modifier =
                            Modifier.weight(1f)
                    )


                    TextButton(

                        onClick = {
                            editandoLinea = true
                        }

                    ) {

                        Text(
                            "Editar"
                        )
                    }
                }
            }


            Spacer(
                Modifier.height(24.dp)
            )


            HorizontalDivider()


            Spacer(
                Modifier.height(16.dp)
            )


            /*
             * ==============================================================
             * 2. IMPORTAR DATOS
             * ==============================================================
             */

            Text(
                "Importar datos",

                style =
                    MaterialTheme
                        .typography
                        .titleLarge
            )


            Spacer(
                Modifier.height(4.dp)
            )


            Column {

                Text(
                    text =
                        "Entra al SIRA para descargar tu historial de notas:",

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall
                )


                Spacer(
                    Modifier.height(2.dp)
                )


                Text(

                    text =
                        "Abrir SIRA",

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall
                            .copy(

                                color =
                                    MaterialTheme
                                        .colorScheme
                                        .primary,

                                textDecoration =
                                    TextDecoration.Underline
                            ),

                    modifier =
                        Modifier.clickable {

                            abrirEnlace(
                                contexto,
                                ENLACE_SIRA
                            )
                        }
                )


                Spacer(
                    Modifier.height(2.dp)
                )


                Text(

                    text =
                        "Luego sube el PDF para cargar tus notas. Luego dirígete a la pantalla pensum y avance para hacer seguimiento a tu historial.",

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall
                )
            }


            Spacer(
                Modifier.height(16.dp)
            )


            Column(

                horizontalAlignment =
                    Alignment.CenterHorizontally,

                modifier =
                    Modifier.fillMaxWidth()
            ) {

                FloatingActionButton(

                    onClick = {

                        selectorPdfNotas.launch(
                            arrayOf(
                                "application/pdf"
                            )
                        )
                    },

                    containerColor =
                        MaterialTheme
                            .colorScheme
                            .primary,

                    contentColor =
                        MaterialTheme
                            .colorScheme
                            .onPrimary

                ) {

                    Icon(

                        painter =
                            painterResource(
                                R.drawable.ic_documento
                            ),

                        contentDescription =
                            "Importar notas desde PDF",

                        modifier =
                            Modifier.size(24.dp)
                    )
                }


                Spacer(
                    Modifier.height(6.dp)
                )


                Text(

                    text =
                        "Importar notas desde PDF",

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall,

                    textAlign =
                        TextAlign.Center
                )

            }


            Spacer(
                Modifier.height(24.dp)
            )


            HorizontalDivider()


            Spacer(
                Modifier.height(16.dp)
            )


            /*
             * ==============================================================
             * 3. INFORME DE AVANCE
             * ==============================================================
             */

            Text(

                "Informe de avance",

                style =
                    MaterialTheme
                        .typography
                        .titleLarge
            )


            Spacer(
                Modifier.height(8.dp)
            )


            Button(

                onClick = {

                    val haceFaltaPermiso =
                        Build.VERSION.SDK_INT <=
                                Build.VERSION_CODES.P &&

                                ContextCompat
                                    .checkSelfPermission(
                                        contexto,
                                        Manifest.permission
                                            .WRITE_EXTERNAL_STORAGE
                                    ) !=
                                PackageManager
                                    .PERMISSION_GRANTED


                    if (haceFaltaPermiso) {

                        permisoAlmacenamiento.launch(

                            Manifest.permission
                                .WRITE_EXTERNAL_STORAGE
                        )

                    } else {

                        generarYAbrirInformePdf()
                    }
                },

                modifier =
                    Modifier.fillMaxWidth()

            ) {

                Text(
                    "Generar y abrir informe de avance"
                )
            }


            Spacer(
                Modifier.height(24.dp)
            )


            HorizontalDivider()


            Spacer(
                Modifier.height(16.dp)
            )


            /*
             * ==============================================================
             * 4. ACCESOS RÁPIDOS
             * ==============================================================
             */

            Text(

                "Accesos rápidos",

                style =
                    MaterialTheme
                        .typography
                        .titleLarge
            )


            Spacer(
                Modifier.height(12.dp)
            )


            Row(

                modifier =
                    Modifier.fillMaxWidth(),

                horizontalArrangement =
                    Arrangement.SpaceEvenly
            ) {

                AccesoRapido(

                    icono =
                        R.drawable.ic_documento,

                    leyenda =
                        "Res091",

                    onClick = {

                        abrirEnlace(
                            contexto,
                            ENLACE_RESOLUCION_091
                        )
                    }
                )


                AccesoRapido(

                    icono =
                        R.drawable.ic_documento,

                    leyenda =
                        "009",

                    onClick = {

                        abrirEnlace(
                            contexto,
                            ENLACE_ACUERDO_009
                        )
                    }
                )


                AccesoRapido(

                    icono =
                        R.drawable.ic_malla,

                    leyenda =
                        "Malla",

                    onClick = {

                        abrirEnlace(
                            contexto,
                            ENLACE_MALLA_CURRICULAR
                        )
                    }
                )


                AccesoRapido(

                    icono =
                        R.drawable.ic_correo,

                    leyenda =
                        "Rep. Facultad",

                    onClick = {

                        abrirCorreo(
                            contexto,
                            CORREO_REPRESENTANTE_FACULTAD
                        )
                    }
                )


                AccesoRapido(

                    icono =
                        R.drawable.ic_correo,

                    leyenda =
                        "Dir. Programa",

                    onClick = {

                        abrirCorreo(
                            contexto,
                            CORREO_DIRECCION_PROGRAMA
                        )
                    }
                )
            }


            Spacer(
                Modifier.height(24.dp)
            )
        }

        /*
         * ------------------------------------------------------------------
         * BOTÓN FLOTANTE: ELIMINAR ESTUDIANTE (esquina inferior izquierda)
         * ------------------------------------------------------------------
         */

        FloatingActionButton(
            onClick = {
                mostrarConfirmacionEliminar = true
            },
            modifier =
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp),
            containerColor =
                MaterialTheme.colorScheme.errorContainer,
            contentColor =
                MaterialTheme.colorScheme.onErrorContainer
        ) {

            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Eliminar estudiante"
            )
        }
    }

    /*
     * ------------------------------------------------------------------
     * CONFIRMACIÓN: ELIMINAR PERMANENTEMENTE EL ESTUDIANTE
     * ------------------------------------------------------------------
     */

    if (mostrarConfirmacionEliminar) {

        AlertDialog(
            onDismissRequest = {
                mostrarConfirmacionEliminar = false
            },
            title = {
                Text("Eliminar permanentemente el estudiante")
            },
            text = {
                Text("¿Estás seguro? Esta acción no se puede deshacer.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.eliminarEstudiante()
                        mostrarConfirmacionEliminar = false

                        Toast.makeText(
                            contexto,
                            "El estudiante fue eliminado permanentemente.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                ) {
                    Text("Sí")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        mostrarConfirmacionEliminar = false
                    }
                ) {
                    Text("No")
                }
            }
        )
    }
}