package com.renea.psicologiauv.gui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.renea.psicologiauv.model.CODIGOS_INGLES
import com.renea.psicologiauv.model.ProgramaM

/* ---------------------------------------------------------------------- */
/* GRADO - requisitos para poder graduarse                                */
/* ---------------------------------------------------------------------- */

@Composable
fun PantallaGrado(
    modifier: Modifier = Modifier,
    programa: ProgramaM
) {

    val practicasCumplidas =
        programa.requisitoPracticasProfesionalesCumplido()

    val creditosCumplidos =
        programa.requisitoCreditosCarreraCumplido()

    val trabajoGradoCumplido =
        programa.requisitoTrabajoDeGradoCumplido()

    val complementariosCumplidos =
        programa.requisitoCreditosComplementariosCumplido()

    val inglesCumplido =
        programa.requisitoInglesCumplido()

    val cursosInglesAprobados =
        programa.cursosInglesAprobados()

    val cumpleTodo =
        programa.cumpleRequisitosGrado()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {

        Text(
            text = "Grado",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        // ================================================================
        // ESTADO GENERAL
        // ================================================================

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor =
                    if (cumpleTodo) Color(0xFFDFF5E1)
                    else MaterialTheme.colorScheme.surfaceVariant
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text =
                        if (cumpleTodo)
                            "✅ Cumples todos los requisitos para grado"
                        else
                            "❌ Aún no cumples todos los requisitos para grado",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color =
                        if (cumpleTodo) Color(0xFF2E7D32)
                        else Color(0xFFC62828),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ================================================================
        // LISTA DE REQUISITOS
        // ================================================================

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {

                Text(
                    text = "Requisitos",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(8.dp))

                FilaRequisitoGrado(
                    titulo = "Prácticas profesionales",
                    cumple = practicasCumplidas
                )

                HorizontalDivider()

                FilaRequisitoGrado(
                    titulo = "168 créditos cursados del pensum",
                    cumple = creditosCumplidos,
                    detalle = "${programa.creditosQueSirvenParaCarrera()} / ${programa.creditosCarrera}"
                )

                HorizontalDivider()

                FilaRequisitoGrado(
                    titulo = "Trabajo de grado",
                    cumple = trabajoGradoCumplido
                )

                HorizontalDivider()

                FilaRequisitoGrado(
                    titulo = "5 créditos complementarios",
                    cumple = complementariosCumplidos,
                    detalle = "${programa.creditosComplementariosAprobados()} / ${programa.creditosComplementarios}"
                )

                HorizontalDivider()

                FilaRequisitoGrado(
                    titulo = "Inglés (2 cursos aprobados)",
                    cumple = inglesCumplido,
                    detalle = "${cursosInglesAprobados.size} / 2"
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ================================================================
        // CURSOS DE INGLÉS RECONOCIDOS
        // ================================================================

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {

                Text(
                    text = "Cursos de inglés reconocidos",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = "Se necesitan al menos 2 aprobados. Si falta algún código, se puede agregar en ProgramaM.kt (lista CODIGOS_INGLES).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(8.dp))

                CODIGOS_INGLES.forEach { (codigo, nombre) ->

                    val aprobado =
                        cursosInglesAprobados.any { it.first == codigo }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Text(
                            text = "$nombre ($codigo)",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Text(
                            text = if (aprobado) "✅" else "—"
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}


/* ---------------------------------------------------------------------- */
/* FILA DE UN REQUISITO DE GRADO                                          */
/* ---------------------------------------------------------------------- */

@Composable
private fun FilaRequisitoGrado(
    titulo: String,
    cumple: Boolean,
    detalle: String? = null
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {

        Column(
            modifier = Modifier.weight(1f)
        ) {

            Text(
                text = titulo,
                style = MaterialTheme.typography.bodyMedium
            )

            if (detalle != null) {

                Text(
                    text = detalle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = if (cumple) "✅" else "❌",
            style = MaterialTheme.typography.titleMedium
        )
    }
}