package com.renea.psicologiauv.gui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.renea.psicologiauv.model.ProgramaM
import com.renea.psicologiauv.ui.theme.DarkGray

/* ---------------------------------------------------------------------- */
/* 3. AVANCE - reporte de progreso                                       */
/* ---------------------------------------------------------------------- */

@Composable
fun PantallaAvance(
    modifier: Modifier = Modifier,
    programa: ProgramaM
) {

    // ====================================================================
    // PROGRESO GENERAL DE LA CARRERA
    // ====================================================================

    val avanceCarrera =
        programa.avanceCarrera()

    // ====================================================================
    // CRÉDITOS QUE SIRVEN PARA EL AVANCE
    // ====================================================================

    val listaFDI =
        programa.estudiante
            ?.asignaturas
            ?.filter {
                it.area ==
                        "Fundamentación Disciplinar e Interdisciplinar" &&
                        it.aprobo()
            }
            .orEmpty()

    val listaFPCA =
        programa.estudiante
            ?.asignaturas
            ?.filter {
                it.area ==
                        "Formación Profesional en Campos de Aplicación" &&
                        it.aprobo()
            }
            .orEmpty()

    val listaFII =
        programa.estudiante
            ?.asignaturas
            ?.filter {
                it.area ==
                        "Formación en investigación e Intervención" &&
                        it.aprobo()
            }
            .orEmpty()

    var creditosFDI =
        listaFDI.sumOf {
            it.creditos
        }

    var creditosFPCA =
        listaFPCA.sumOf {
            it.creditos
        }

    var creditosFII =
        listaFII.sumOf {
            it.creditos
        }

    if (creditosFDI > programa.creditosFDI) {
        creditosFDI = programa.creditosFDI
    }

    if (creditosFPCA > programa.creditosFPCA) {
        creditosFPCA = programa.creditosFPCA
    }

    if (creditosFII > programa.creditosFII) {
        creditosFII = programa.creditosFII
    }

    // ====================================================================
    // CRÉDITOS COMPLEMENTARIOS (también cuentan para "Progreso carrera")
    // ====================================================================

    val creditosComplementariosAprobados =
        programa.creditosComplementariosAprobados()

    val creditosCarreraTotal =
        programa.creditosCarrera

    val creditosCursados =
        (
                creditosFDI +
                        creditosFPCA +
                        creditosFII
                ).coerceAtMost(
                creditosCarreraTotal
            )

    // ====================================================================
    // PANTALLA
    // ====================================================================

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .padding(14.dp)
                .verticalScroll(
                    rememberScrollState()
                )
    ) {

        // ================================================================
        // PROGRESO CARRERA
        // ================================================================

        Card(
            modifier =
                Modifier.fillMaxWidth(),

            elevation =
                CardDefaults.cardElevation(
                    defaultElevation = 3.dp
                )
        ) {

            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 18.dp
                        ),

                horizontalAlignment =
                    Alignment.CenterHorizontally
            ) {

                Text(
                    text =
                        "Progreso carrera",

                    style =
                        MaterialTheme
                            .typography
                            .titleMedium,

                    fontWeight =
                        FontWeight.Bold,

                    textAlign =
                        TextAlign.Center
                )

                Spacer(
                    modifier =
                        Modifier.height(14.dp)
                )

                // ========================================================
                // CÍRCULO DE PROGRESO
                // ========================================================

                CirculoProgresoCarrera(
                    progreso =
                        avanceCarrera,

                    creditosCursados =
                        creditosCursados,

                    creditosCarrera =
                        creditosCarreraTotal
                )

                Spacer(
                    modifier =
                        Modifier.height(10.dp)
                )

                Text(
                    text =
                        "Créditos cursados",

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall,

                    color =
                        MaterialTheme
                            .colorScheme
                            .onSurfaceVariant,

                    textAlign =
                        TextAlign.Center
                )

                Text(
                    text =
                        "$creditosCursados / $creditosCarreraTotal",

                    style =
                        MaterialTheme
                            .typography
                            .labelMedium,

                    fontWeight =
                        FontWeight.Bold,

                    textAlign =
                        TextAlign.Center
                )
            }
        }

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        // ================================================================
        // AVANCE POR ÁREA
        // ================================================================

        val avances =
            programa.avanceAreas()

        // ================================================================
        // BARRAS VERTICALES
        // ================================================================

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(230.dp),

            horizontalArrangement =
                Arrangement.SpaceEvenly,

            verticalAlignment =
                Alignment.Bottom
        ) {

            avances.forEach {
                    (area, porcentaje) ->

                BarraVerticalArea(
                    nombre =
                        area,

                    porcentaje =
                        porcentaje,

                    modifier =
                        Modifier.weight(1f)
                )
            }
        }

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )

        // ================================================================
        // CRÉDITOS COMPLEMENTARIOS
        // ================================================================

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        Card(
            modifier =
                Modifier.fillMaxWidth(),

            elevation =
                CardDefaults.cardElevation(
                    defaultElevation = 3.dp
                )
        ) {

            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 18.dp
                        )
            ) {

                BarraProgresoComplementarios(
                    creditosAprobados =
                        programa
                            .creditosComplementariosAprobados(),

                    creditosTotales =
                        programa
                            .creditosComplementarios
                )
            }
        }

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )
    }
}


// ========================================================================
// BARRA VERTICAL DE ÁREA
// ========================================================================

@Composable
private fun BarraVerticalArea(
    nombre: String,
    porcentaje: Float,
    modifier: Modifier = Modifier
) {

    val progreso =
        (porcentaje / 100f)
            .coerceIn(
                0f,
                1f
            )

    Column(
        modifier =
            modifier
                .fillMaxHeight()
                .padding(
                    horizontal = 5.dp
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Bottom
    ) {

        // ================================================================
        // PORCENTAJE
        // ================================================================

        Text(
            text =
                "${"%.1f".format(porcentaje)}%",

            style =
                MaterialTheme
                    .typography
                    .labelSmall,

            fontWeight =
                FontWeight.Bold,

            textAlign =
                TextAlign.Center
        )

        Spacer(
            modifier =
                Modifier.height(5.dp)
        )

        // ================================================================
        // BARRA
        // ================================================================

        Box(
            modifier =
                Modifier
                    .width(35.dp)
                    .height(110.dp),

            contentAlignment =
                Alignment.BottomCenter
        ) {

            // ------------------------------------------------------------
            // FONDO DE LA BARRA
            // ------------------------------------------------------------

            Surface(
                modifier =
                    Modifier
                        .fillMaxHeight()
                        .width(42.dp),

                shape =
                    MaterialTheme
                        .shapes
                        .medium,

                color =
                    DarkGray
            ) {}

            // ------------------------------------------------------------
            // PARTE COMPLETADA
            // ------------------------------------------------------------

            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(
                            progreso
                        )
            ) {

                Surface(
                    modifier =
                        Modifier.fillMaxSize(),

                    shape =
                        MaterialTheme
                            .shapes
                            .medium,

                    color =
                        if (progreso >= 1f) {

                            Color(0xFF2E7D32)

                        } else {

                            MaterialTheme
                                .colorScheme
                                .primary
                        }
                ) {}
            }
        }

        Spacer(
            modifier =
                Modifier.height(7.dp)
        )

        // ================================================================
        // NOMBRE DEL ÁREA
        // ================================================================

        Text(
            text =
                nombre,

            style =
                MaterialTheme
                    .typography
                    .labelSmall,

            color =
                MaterialTheme
                    .colorScheme
                    .onSurfaceVariant,

            textAlign =
                TextAlign.Center,

            maxLines =
                3,

            modifier =
                Modifier.fillMaxWidth()
        )
    }
}


// ========================================================================
// BARRA DE 5 CRÉDITOS COMPLEMENTARIOS
// ========================================================================

@Composable
private fun BarraProgresoComplementarios(
    creditosAprobados: Int,
    creditosTotales: Int
) {

    val progreso =
        creditosAprobados
            .coerceIn(
                0,
                creditosTotales
            )

    Column(
        modifier =
            Modifier.fillMaxWidth(),

        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        // ================================================================
        // TÍTULO
        // ================================================================

        Text(
            text =
                "Créditos complementarios",

            style =
                MaterialTheme
                    .typography
                    .titleMedium,

            fontWeight =
                FontWeight.Bold,

            textAlign =
                TextAlign.Center
        )

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )

        // ================================================================
        // CINCO UNIDADES VISUALES
        // ================================================================

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = 16.dp
                    ),

            horizontalArrangement =
                Arrangement.spacedBy(8.dp)
        ) {

            repeat(
                creditosTotales
            ) { indice ->

                val completado =
                    indice < progreso

                Surface(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(28.dp),

                    shape =
                        MaterialTheme
                            .shapes
                            .small,

                    color =
                        if (completado) {

                            if (progreso ==
                                creditosTotales
                            ) {

                                Color(0xFF2E7D32)

                            } else {

                                MaterialTheme
                                    .colorScheme
                                    .primary
                            }

                        } else {

                            DarkGray
                        }
                ) {}
            }
        }

        Spacer(
            modifier =
                Modifier.height(10.dp)
        )

        // ================================================================
        // CONTADOR
        // ================================================================

        Text(
            text =
                "$progreso / $creditosTotales créditos",

            style =
                MaterialTheme
                    .typography
                    .labelMedium,

            fontWeight =
                FontWeight.Bold,

            color =
                MaterialTheme
                    .colorScheme
                    .onSurfaceVariant
        )
    }
}


// ========================================================================
// CÍRCULO DE PROGRESO DE LA CARRERA
// ========================================================================

@Composable
private fun CirculoProgresoCarrera(
    progreso: Float,
    creditosCursados: Int,
    creditosCarrera: Int
) {

    val progresoSeguro =
        (progreso / 100f)
            .coerceIn(
                0f,
                1f
            )

    val colorProgreso =
        if (progresoSeguro >= 1f) {

            Color(0xFF2E7D32)

        } else {

            MaterialTheme
                .colorScheme
                .primary
        }

    // Fondo oscuro del círculo

    val colorFondo =
        DarkGray

    Box(
        modifier =
            Modifier.size(150.dp),

        contentAlignment =
            Alignment.Center
    ) {

        Canvas(
            modifier =
                Modifier.fillMaxSize()
        ) {

            val grosor =
                16.dp.toPx()

            val diametro =
                size.minDimension -
                        grosor

            val izquierda =
                (size.width -
                        diametro) / 2f

            val arriba =
                (size.height -
                        diametro) / 2f

            // ============================================================
            // CÍRCULO DE FONDO
            // ============================================================

            drawArc(
                color =
                    colorFondo,

                startAngle =
                    -90f,

                sweepAngle =
                    360f,

                useCenter =
                    false,

                topLeft =
                    Offset(
                        izquierda,
                        arriba
                    ),

                size =
                    Size(
                        diametro,
                        diametro
                    ),

                style =
                    Stroke(
                        width =
                            grosor,

                        cap =
                            StrokeCap.Round
                    )
            )

            // ============================================================
            // PROGRESO
            // ============================================================

            drawArc(
                color =
                    colorProgreso,

                startAngle =
                    -90f,

                sweepAngle =
                    360f *
                            progresoSeguro,

                useCenter =
                    false,

                topLeft =
                    Offset(
                        izquierda,
                        arriba
                    ),

                size =
                    Size(
                        diametro,
                        diametro
                    ),

                style =
                    Stroke(
                        width =
                            grosor,

                        cap =
                            StrokeCap.Round
                    )
            )
        }

        // ================================================================
        // PORCENTAJE DENTRO DEL CÍRCULO
        // ================================================================

        Text(
            text =
                "${"%.1f".format(progreso)}%",

            style =
                MaterialTheme
                    .typography
                    .headlineSmall,

            fontWeight =
                FontWeight.Bold,

            color =
                colorProgreso,

            textAlign =
                TextAlign.Center
        )
    }
}