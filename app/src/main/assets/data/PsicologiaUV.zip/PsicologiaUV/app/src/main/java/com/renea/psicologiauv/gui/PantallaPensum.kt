package com.renea.psicologiauv.gui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.renea.psicologiauv.model.Asignatura
import com.renea.psicologiauv.model.Estudiante
import com.renea.psicologiauv.model.ProgramaM

/* ---------------------------------------------------------------------- */
/* 1. PENSUM - materias agrupadas por semestre, con sus créditos         */
/* ---------------------------------------------------------------------- */

@Composable
fun PantallaPensum(
    modifier: Modifier = Modifier,
    estudiante: Estudiante,
    viewModel: ControlV
) {

    /*
     * ProgramaM es quien contiene la lógica académica del programa.
     *
     * La pantalla NO vuelve a calcular promedios ni avances.
     * Simplemente solicita la información al modelo y la muestra.
     */
    val programa = viewModel.programa

    // Estado para el filtro
    var mostrarFiltros by remember { mutableStateOf(false) }
    var filtroArea by remember { mutableStateOf<String?>(null) }
    var filtroAprobado by remember { mutableStateOf<Boolean?>(null) }

    // Obtener todas las áreas únicas de las asignaturas
    val areasDisponibles = estudiante.asignaturas
        .map { it.area }
        .distinct()
        .sorted()

    // Filtrar asignaturas
    val asignaturasFiltradas = estudiante.asignaturas
        .filter { materia ->
            var cumpleFiltro = true
            if (filtroArea != null) {
                cumpleFiltro = cumpleFiltro && materia.area == filtroArea
            }
            if (filtroAprobado != null) {
                cumpleFiltro = cumpleFiltro && materia.aprobo() == filtroAprobado
            }
            cumpleFiltro
        }

    val porSemestre = asignaturasFiltradas
        .groupBy { it.semestre }
        .toSortedMap()

    var materiaSeleccionada by remember {
        mutableStateOf<Asignatura?>(null)
    }

    /*
     * Controla si se muestra el módulo de
     * asignaturas electivas.
     */
    var mostrarElectivas by remember {
        mutableStateOf(false)
    }

    /*
     * Controlan el botón para agregar créditos complementarios:
     * primero se elige el tipo ("Agregar asignatura" o
     * "Agregar actividad") y luego se abre el formulario
     * correspondiente.
     */
    var mostrarMenuAgregarComplementaria by remember {
        mutableStateOf(false)
    }

    var mostrarDialogoAgregarAsignatura by remember {
        mutableStateOf(false)
    }

    var mostrarDialogoAgregarActividad by remember {
        mutableStateOf(false)
    }

    /*
     * Los semestres 1 al 10 aparecen en la pantalla principal.
     *
     * El semestre 0 NO aparece aquí porque corresponde
     * a las actividades/asignaturas electivas.
     */
    val semestresOrdenados = porSemestre.keys
        .filter { it in 1..10 }
        .sorted()

    /*
     * Las asignaturas con semestre 0 serán mostradas
     * dentro del módulo de asignaturas electivas.
     */
    val materiasElectivas = porSemestre[0].orEmpty()

    /*
     * Las asignaturas con semestre 11 o superior se agrupan
     * en un bloque especial "11 o más"
     */
    val materiasSemestre11OMas = porSemestre
        .filterKeys { it >= 11 }
        .values
        .flatten()
        .sortedBy { it.semestre }

    Box(
        modifier = modifier.fillMaxSize()
    ) {

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {

            semestresOrdenados.forEach { semestre ->

                val materias = porSemestre[semestre].orEmpty()

                item {

                    /*
                     * El promedio ya no se calcula aquí.
                     *
                     * ProgramaM es el encargado de realizar
                     * el cálculo académico.
                     */
                    val promedio = programa.promedioSemestre(semestre)

                    /*
                     * Contenedor del semestre.
                     */
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                top = 10.dp,
                                bottom = 4.dp
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 10.dp
                                )
                        ) {

                            /*
                             * Título centrado.
                             */
                            Text(
                                text = "Semestre $semestre",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )

                            Spacer(Modifier.height(4.dp))


                        }
                    }
                }

                items(materias) { materia ->

                    ListItem(
                        modifier = Modifier.clickable {
                            materiaSeleccionada = materia
                        },
                        headlineContent = {
                            Text(materia.nombre)
                        },
                        supportingContent = {
                            Column {
                                Text(materia.codigo)
                                Text(
                                    text = "Área: ${materia.area}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        trailingContent = {

                            Column(
                                horizontalAlignment = Alignment.End
                            ) {

                                Text("${materia.creditos} créditos")

                                Text("Nota: ${materia.textoNota()}")

                                // Indicador de estado de aprobación
                                if (materia.nota > 0 || materia.notaEspecial != null) {
                                    Text(
                                        text = if (materia.aprobo()) "✅ Aprobada" else "❌ No aprobada",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (materia.aprobo())
                                            Color(0xFF2E7D32)
                                        else
                                            Color(0xFFC62828)
                                    )
                                }
                            }
                        }
                    )

                    HorizontalDivider()
                }
            }

            // ========================= SEMESTRE 11 O MÁS =========================
            if (materiasSemestre11OMas.isNotEmpty()) {

                item {
                    val promedio = programa.promedioSemestreGeneral(materiasSemestre11OMas)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                top = 10.dp,
                                bottom = 4.dp
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer
                        )
                    ) {

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 10.dp
                                )
                        ) {

                            Text(
                                text = "11 o más",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )

                            Spacer(Modifier.height(4.dp))

                            Text(
                                text = if (promedio > 0f) {
                                    "Promedio: ${"%.2f".format(promedio)}"
                                } else {
                                    "-"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                items(materiasSemestre11OMas) { materia ->

                    ListItem(
                        modifier = Modifier.clickable {
                            materiaSeleccionada = materia
                        },
                        headlineContent = {
                            Text(materia.nombre)
                        },
                        supportingContent = {
                            Column {
                                Text(materia.codigo)
                                Text(
                                    text = "Semestre ${materia.semestre} • Área: ${materia.area}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        trailingContent = {

                            Column(
                                horizontalAlignment = Alignment.End
                            ) {

                                Text("${materia.creditos} créditos")

                                Text("Nota: ${materia.textoNota()}")

                                // Indicador de estado de aprobación
                                if (materia.nota > 0 || materia.notaEspecial != null) {
                                    Text(
                                        text = if (materia.aprobo()) "✅ Aprobada" else "❌ No aprobada",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (materia.aprobo())
                                            Color(0xFF2E7D32)
                                        else
                                            Color(0xFFC62828)
                                    )
                                }
                            }
                        }
                    )

                    HorizontalDivider()
                }
            }

            item {
                Spacer(Modifier.height(80.dp))
            }
        }

        // ========================= BOTÓN FLOTANTE DE FILTROS (ARRIBA) =========================
        FloatingActionButton(
            onClick = {
                mostrarFiltros = !mostrarFiltros
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = "Filtrar"
            )
        }

        // ========================= PANEL DE FILTROS =========================
        if (mostrarFiltros) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 80.dp, end = 16.dp)
                    .width(280.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Filtros",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Filtro por área
                    Text(
                        text = "Área",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))

                    // Opción "Todas"
                    FilterChip(
                        selected = filtroArea == null,
                        onClick = { filtroArea = null },
                        label = { Text("Todas") },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    areasDisponibles.forEach { area ->
                        FilterChip(
                            selected = filtroArea == area,
                            onClick = {
                                filtroArea = if (filtroArea == area) null else area
                            },
                            label = { Text(area) },
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // Filtro por estado de aprobación
                    Text(
                        text = "Estado",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))

                    FilterChip(
                        selected = filtroAprobado == null,
                        onClick = { filtroAprobado = null },
                        label = { Text("Todos") },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    FilterChip(
                        selected = filtroAprobado == true,
                        onClick = {
                            filtroAprobado = if (filtroAprobado == true) null else true
                        },
                        label = { Text("✅ Aprobadas") },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    FilterChip(
                        selected = filtroAprobado == false,
                        onClick = {
                            filtroAprobado = if (filtroAprobado == false) null else false
                        },
                        label = { Text("❌ No aprobadas") },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    Spacer(Modifier.height(12.dp))

                    // Botón para limpiar filtros
                    TextButton(
                        onClick = {
                            filtroArea = null
                            filtroAprobado = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Limpiar filtros")
                    }
                }
            }
        }

        /*
         * ----------------------------------------------------------------
         * BOTÓN FLOTANTE DE ASIGNATURAS ELECTIVAS
         * ----------------------------------------------------------------
         *
         * Solo aparece si existen asignaturas con semestre 0.
         */
        if (materiasElectivas.isNotEmpty()) {

            FloatingActionButton(
                onClick = {
                    mostrarElectivas = true
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {

                Text(
                    text = "+",
                    style = MaterialTheme.typography.headlineSmall
                )
            }
        }

        /*
         * ----------------------------------------------------------------
         * BOTÓN FLOTANTE PARA AGREGAR CRÉDITOS COMPLEMENTARIOS
         * ----------------------------------------------------------------
         */
        FloatingActionButton(
            onClick = {
                mostrarMenuAgregarComplementaria = true
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {

            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Agregar créditos complementarios"
            )
        }
    }

    /*
     * ------------------------------------------------------------------
     * MENÚ PARA ELEGIR EL TIPO DE CRÉDITO COMPLEMENTARIO A AGREGAR
     * ------------------------------------------------------------------
     */
    if (mostrarMenuAgregarComplementaria) {

        AlertDialog(
            onDismissRequest = {
                mostrarMenuAgregarComplementaria = false
            },
            title = {
                Text("Créditos complementarios")
            },
            text = {
                Column {
                    Text(
                        text = "¿Qué deseas agregar?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        mostrarMenuAgregarComplementaria = false
                        mostrarDialogoAgregarAsignatura = true
                    }
                ) {
                    Text("Agregar asignatura")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        mostrarMenuAgregarComplementaria = false
                        mostrarDialogoAgregarActividad = true
                    }
                ) {
                    Text("Agregar actividad")
                }
            }
        )
    }

    /*
     * ------------------------------------------------------------------
     * FORMULARIO: AGREGAR ASIGNATURA COMPLEMENTARIA
     * ------------------------------------------------------------------
     */
    if (mostrarDialogoAgregarAsignatura) {

        DialogoAgregarAsignaturaComplementaria(
            viewModel = viewModel,
            onDismiss = {
                mostrarDialogoAgregarAsignatura = false
            }
        )
    }

    /*
     * ------------------------------------------------------------------
     * FORMULARIO: AGREGAR ACTIVIDAD COMPLEMENTARIA
     * ------------------------------------------------------------------
     */
    if (mostrarDialogoAgregarActividad) {

        DialogoAgregarActividadComplementaria(
            viewModel = viewModel,
            onDismiss = {
                mostrarDialogoAgregarActividad = false
            }
        )
    }

    /*
     * ------------------------------------------------------------------
     * MÓDULO DE ASIGNATURAS ELECTIVAS
     * ------------------------------------------------------------------
     */
    if (mostrarElectivas) {

        /*
         * El promedio de las Electivas también
         * es responsabilidad de ProgramaM.
         *
         * Como las Electivas pertenecen al semestre 0,
         * utilizamos promedioSemestre(0).
         */
        val promedio = programa.promedioSemestre(0)

        AlertDialog(
            onDismissRequest = {
                mostrarElectivas = false
            },
            title = {
                Text(
                    text = "Asignaturas Electivas",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(
                            max = 500.dp
                        )
                ) {

                    /*
                     * Promedio de las actividades Electivas.
                     */
                    Text(
                        text = if (promedio > 0f) {
                            "Promedio: ${"%.2f".format(promedio)}"
                        } else {
                            "Promedio: -"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )

                    Spacer(Modifier.height(12.dp))

                    /*
                     * Lista de asignaturas electivas.
                     */
                    LazyColumn {
                        items(materiasElectivas) { materia ->

                            ListItem(
                                modifier = Modifier.clickable {

                                    /*
                                     * Seleccionamos la materia
                                     * para utilizar el mismo
                                     * diálogo de edición que
                                     * utilizan las demás.
                                     */
                                    materiaSeleccionada = materia

                                    /*
                                     * Cerramos el módulo.
                                     */
                                    mostrarElectivas = false
                                },
                                headlineContent = {
                                    Text(materia.nombre)
                                },
                                supportingContent = {
                                    Column {
                                        Text(materia.codigo)
                                        Text(
                                            text = "Área: ${materia.area}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                trailingContent = {
                                    Column(
                                        horizontalAlignment = Alignment.End
                                    ) {
                                        Text("${materia.creditos} créditos")
                                        Text("Nota: ${materia.textoNota()}")
                                    }
                                }
                            )

                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        mostrarElectivas = false
                    }
                ) {
                    Text("Cerrar")
                }
            }
        )
    }

    /* ------------------------------------------------------------------ */
    /* INFORMACIÓN / EDICIÓN DE UNA ASIGNATURA                            */
    /* ------------------------------------------------------------------ */

    materiaSeleccionada?.let { materia ->

        DialogoEditarAsignatura(
            materia = materia,
            viewModel = viewModel,
            onDismiss = {
                materiaSeleccionada = null
            }
        )
    }
}

/* ---------------------------------------------------------------------- */
/* DIÁLOGO PARA AGREGAR UNA ASIGNATURA COMPLEMENTARIA                     */
/* ---------------------------------------------------------------------- */

@Composable
private fun DialogoAgregarAsignaturaComplementaria(
    viewModel: ControlV,
    onDismiss: () -> Unit
) {

    var nombreTexto by remember { mutableStateOf("") }
    var codigoTexto by remember { mutableStateOf("") }
    var semestreTexto by remember { mutableStateOf("") }
    var creditosTexto by remember { mutableStateOf("") }
    var notaTexto by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Agregar asignatura")
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(
                    rememberScrollState()
                )
            ) {

                OutlinedTextField(
                    value = nombreTexto,
                    onValueChange = { nombreTexto = it },
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = codigoTexto,
                    onValueChange = { codigoTexto = it },
                    label = { Text("Código") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = semestreTexto,
                    onValueChange = { semestreTexto = it },
                    label = { Text("Semestre") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = creditosTexto,
                    onValueChange = { creditosTexto = it },
                    label = { Text("Número de créditos") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = notaTexto,
                    onValueChange = { notaTexto = it },
                    label = { Text("Nota") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        confirmButton = {
            Button(
                onClick = {

                    val creditos = creditosTexto.toIntOrNull()
                    val semestre = semestreTexto.toIntOrNull()
                    val nota = notaTexto.toFloatOrNull() ?: 0f

                    if (nombreTexto.isNotBlank() &&
                        codigoTexto.isNotBlank() &&
                        semestre != null &&
                        creditos != null
                    ) {

                        viewModel.agregarAsignaturaComplementaria(
                            nombre = nombreTexto,
                            codigo = codigoTexto,
                            semestre = semestre,
                            creditos = creditos,
                            nota = nota
                        )

                        onDismiss()
                    }
                }
            ) {
                Text("Guardar")
            }
        }
    )
}

/* ---------------------------------------------------------------------- */
/* DIÁLOGO PARA AGREGAR UNA ACTIVIDAD COMPLEMENTARIA                      */
/* ---------------------------------------------------------------------- */

@Composable
private fun DialogoAgregarActividadComplementaria(
    viewModel: ControlV,
    onDismiss: () -> Unit
) {

    var nombreTexto by remember { mutableStateOf("") }
    var creditosTexto by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Agregar actividad")
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(
                    rememberScrollState()
                )
            ) {

                OutlinedTextField(
                    value = nombreTexto,
                    onValueChange = { nombreTexto = it },
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = creditosTexto,
                    onValueChange = { creditosTexto = it },
                    label = { Text("Número de créditos") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        confirmButton = {
            Button(
                onClick = {

                    val creditos = creditosTexto.toIntOrNull()

                    if (nombreTexto.isNotBlank() && creditos != null) {

                        viewModel.agregarActividadComplementaria(
                            nombre = nombreTexto,
                            creditos = creditos
                        )

                        onDismiss()
                    }
                }
            ) {
                Text("Guardar")
            }
        }
    )
}

/**
 * Calcula el promedio de una lista de asignaturas
 */
private fun ProgramaM.promedioSemestreGeneral(materias: List<Asignatura>): Float {
    val notasValidas = materias
        .mapNotNull { it.nota }
        .filter { it > 0 }

    return if (notasValidas.isNotEmpty()) {
        notasValidas.average().toFloat()
    } else {
        0f
    }
}


/* ---------------------------------------------------------------------- */
/* DIÁLOGO PARA EDITAR UNA ASIGNATURA                                    */
/* ---------------------------------------------------------------------- */

@Composable
private fun DialogoEditarAsignatura(
    materia: Asignatura,
    viewModel: ControlV,
    onDismiss: () -> Unit
) {

    var semestreTexto by remember(materia.semestre) {
        mutableStateOf(materia.semestre.toString())
    }

    var notaTexto by remember(materia.nota) {
        mutableStateOf(
            if (materia.nota > 0) materia.nota.toString() else ""
        )
    }

    var nombreTexto by remember(materia.nombre) {
        mutableStateOf(materia.nombre)
    }

    var codigoTexto by remember(materia.codigo) {
        mutableStateOf(materia.codigo)
    }

    /*
     * Las materias cuyo componente contiene
     * "Electiva" pueden modificar nombre y código.
     */
    val esElectiva = materia.componente.contains(
        "Electiva", ignoreCase = true
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Editar asignatura")
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(
                    rememberScrollState()
                )
            ) {

                /*
                 * Nombre y código solamente aparecen
                 * para las electivas.
                 */
                if (esElectiva) {

                    OutlinedTextField(
                        value = nombreTexto,
                        onValueChange = { nombreTexto = it },
                        label = { Text("Nombre") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = codigoTexto,
                        onValueChange = { codigoTexto = it },
                        label = { Text("Código") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))
                }

                /*
                 * Todas las asignaturas pueden
                 * modificar el semestre.
                 */
                OutlinedTextField(
                    value = semestreTexto,
                    onValueChange = { semestreTexto = it },
                    label = { Text("Semestre") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                /*
                 * Todas las asignaturas pueden
                 * modificar la nota.
                 */
                OutlinedTextField(
                    value = notaTexto,
                    onValueChange = { notaTexto = it },
                    label = { Text("Nota") },
                    placeholder = { Text(materia.notaEspecial ?: "-") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                /*
                 * Botón para reiniciar la materia: borra la nota
                 * numérica y cualquier marca especial (C.U, E.X, A.P),
                 * dejándola como si no se hubiera cursado.
                 */
                TextButton(
                    onClick = {
                        viewModel.cambiarNotaAsignatura(materia.codigo, 0f)
                        onDismiss()
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Reiniciar")
                }

                /*
                 * Botón para eliminar la materia. Solo aparece si es una
                 * actividad/asignatura complementaria (complementaria ==
                 * true); el resto de las materias del pensum no se pueden
                 * eliminar, y ControlV.eliminarAsignaturaComplementaria
                 * también protege esa regla del lado del modelo.
                 */
                if (materia.complementaria) {

                    TextButton(
                        onClick = {
                            viewModel.eliminarAsignaturaComplementaria(materia.codigo)
                            onDismiss()
                        },
                        modifier = Modifier.align(Alignment.End),
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text("Eliminar")
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        confirmButton = {
            Button(
                onClick = {

                    /*
                     * Guardamos semestre.
                     */
                    semestreTexto.toIntOrNull()?.let {
                        viewModel.cambiarSemestreAsignatura(materia.codigo, it)
                    }

                    /*
                     * Guardamos nota.
                     */
                    notaTexto.toFloatOrNull()?.let {
                        viewModel.cambiarNotaAsignatura(materia.codigo, it)
                    }

                    /*
                     * Si es electiva, también
                     * guardamos nombre y código.
                     */
                    if (esElectiva) {
                        viewModel.cambiarNombreAsignatura(materia.codigo, nombreTexto)
                        viewModel.cambiarCodigoAsignatura(materia.codigo, codigoTexto)
                    }

                    onDismiss()
                }
            ) {
                Text("Guardar")
            }
        }
    )
}