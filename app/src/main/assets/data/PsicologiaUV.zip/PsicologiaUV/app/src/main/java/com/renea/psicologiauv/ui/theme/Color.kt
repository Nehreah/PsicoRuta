package com.renea.psicologiauv.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================
// ROJOS
// ============================================================

val Red = Color(0xFF880909)
val DeepRed = Color(0xFF8B2635)
val Wine = Color(0xFF6D1F2B)
val Burgundy = Color(0xFF4A1018)
val DarkRed = Color(0xFF3A0D13)

// ============================================================
// NEUTROS
// ============================================================

val Black = Color(0xFF0D0D0D)
val Charcoal = Color(0xFF181818)
val DarkGray = Color(0xFF242424)

val White = Color(0xFFF5F5F5)
val LightGray = Color(0xFFEAEAEA)
val OffWhite = Color(0xFFE6E6E6)

val Gray = Color(0xFFBEBEBE)

// ============================================================
// ESTADOS
// ============================================================

// Verde oscuro para texto sobre fondos claros
val SuccessLight = Color(0xFF1B5E20)

// Verde más claro para texto sobre fondos oscuros
val SuccessDark = Color(0xFF81C784)

// Rojo oscuro para texto sobre fondos claros
val ErrorLight = Color(0xFFB71C1C)

// Rojo claro para texto sobre fondos oscuros
val ErrorDark = Color(0xFFEF9A9A)