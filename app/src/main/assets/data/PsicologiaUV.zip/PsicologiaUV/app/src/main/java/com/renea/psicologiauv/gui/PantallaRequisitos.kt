package com.renea.psicologiauv.gui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.renea.psicologiauv.model.AvanceLineaProfesional
import com.renea.psicologiauv.model.ProgramaM


@Composable
fun PantallaRequisitos(
    modifier: Modifier = Modifier,
    programa: ProgramaM
) {

    // ================================================================
    // LÍNEA PROFESIONAL SELECCIONADA
    // ================================================================

    var otraLineaSeleccionada by remember(
        programa.estudiante?.linea
    ) {
        mutableStateOf(
            programa.estudiante?.linea
                ?.takeIf { it != "No" }
        )
    }


    // ================================================================
    // CRÉDITOS DE LA LÍNEA PROFESIONAL SELECCIONADA
    // ================================================================

    val creditosLineaSeleccionada =
        programa.estudiante
            ?.asignaturas
            ?.filter {
                it.lineaProfesional == otraLineaSeleccionada &&
                        it.aprobo()
            }
            ?.sumOf {
                it.creditos
            }
            ?: 0


    // ================================================================
    // CRÉDITOS PROFESIONALES
    // ================================================================

    val creditosProfesionales =
        programa.creditosDeProfesionalizacion()


    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        // ============================================================
        // REQUISITOS PARA PRÁCTICAS
        // ============================================================

        Card(
            modifier =
                Modifier.fillMaxWidth(),

            elevation =
                CardDefaults.cardElevation(
                    defaultElevation = 3.dp
                )
        ) {

            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 14.dp
                        )
            ) {

                Text(
                    text =
                        "Requisitos para iniciar prácticas profesionales",

                    textAlign =
                        TextAlign.Center,

                    style =
                        MaterialTheme.typography.titleSmall,

                    fontWeight =
                        FontWeight.Bold
                )


                Spacer(
                    modifier = Modifier.height(10.dp)
                )


                // ====================================================
                // INDICADORES DE CRÉDITOS
                // ====================================================

                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.SpaceEvenly,

                    verticalAlignment =
                        Alignment.Top
                ) {

                    IndicadorCreditos(
                        titulo =
                            "Línea profesional ${
                                otraLineaSeleccionada ?: "No"
                            }",

                        creditos =
                            creditosLineaSeleccionada,

                        total =
                            programa.creditosLinea
                    )


                    IndicadorCreditos(
                        titulo =
                            "Asignaturas profesionales",

                        creditos =
                            creditosProfesionales,

                        total =
                            programa.creditosProfesionales
                    )
                }


                Spacer(
                    modifier = Modifier.height(12.dp)
                )


                HorizontalDivider(
                    modifier =
                        Modifier.padding(
                            vertical = 2.dp
                        )
                )


                Spacer(
                    modifier = Modifier.height(10.dp)
                )


                // ====================================================
                // REQUISITOS DE ASIGNATURAS
                // ====================================================

                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    CajonRequisitoMateria(
                        nombre =
                            "Ética del ejercicio profesional",

                        cumple =
                            programa.requisitosPracticasEtica(),

                        modifier =
                            Modifier.weight(1f)
                    )


                    CajonRequisitoMateria(
                        nombre =
                            "Evaluación y Diagnóstico Psicológico",

                        cumple =
                            programa.requisitosPracticasDiagnostico(),

                        modifier =
                            Modifier.weight(1f)
                    )
                }


                Spacer(
                    modifier = Modifier.height(6.dp)
                )


                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    CajonRequisitoMateria(
                        nombre =
                            "Práctica de fundamentación profesional I",

                        cumple =
                            programa.requisitosPracticasFundamentacionI(),

                        modifier =
                            Modifier.weight(1f)
                    )


                    CajonRequisitoMateria(
                        nombre =
                            "Práctica de fundamentación profesional II",

                        cumple =
                            programa.requisitosPracticasFundamentacionII(),

                        modifier =
                            Modifier.weight(1f)
                    )
                }


                Spacer(
                    modifier = Modifier.height(10.dp)
                )


                // ====================================================
                // TODAS LAS LÍNEAS PROFESIONALES
                // ====================================================

                val lineasFaltantes =
                    obtenerLineasFaltantes(programa)

                val todasLasLineasCursadas =
                    lineasFaltantes.isEmpty()


                // ====================================================
                // TÍTULO DEL REQUISITO
                // ====================================================

                Text(
                    text =
                        if (todasLasLineasCursadas) {
                            "Cursó al menos un nivel de cada línea"
                        } else {
                            "No cursó al menos un nivel de cada línea"
                        },

                    style =
                        MaterialTheme
                            .typography
                            .labelLarge,

                    fontWeight =
                        FontWeight.SemiBold,

                    color =
                        if (todasLasLineasCursadas) {
                            Color(0xFF2E7D32)
                        } else {
                            Color(0xFFC62828)
                        },

                    textAlign =
                        TextAlign.Center,

                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(
                                vertical = 4.dp
                            )
                )


                Spacer(
                    modifier = Modifier.height(6.dp)
                )


                // ====================================================
                // AVANCE DE TODAS LAS LÍNEAS PROFESIONALES
                // ====================================================

                val avanceLineas =
                    programa.avanceLineasProfundizacion()


                val lineas =
                    listOf(
                        "Social",
                        "Organizacional",
                        "Educativa",
                        "Clínica/NeuroClínica"
                    )


                Column(
                    modifier =
                        Modifier.fillMaxWidth(),

                    verticalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    // =================================================
                    // PRIMERA FILA
                    // =================================================

                    Row(
                        modifier =
                            Modifier.fillMaxWidth(),

                        horizontalArrangement =
                            Arrangement.spacedBy(6.dp)
                    ) {

                        lineas
                            .take(2)
                            .forEach { linea ->

                                CajonNivelLinea(
                                    linea =
                                        linea,

                                    avance =
                                        avanceLineas[linea],

                                    modifier =
                                        Modifier.weight(1f)
                                )
                            }
                    }


                    // =================================================
                    // SEGUNDA FILA
                    // =================================================

                    Row(
                        modifier =
                            Modifier.fillMaxWidth(),

                        horizontalArrangement =
                            Arrangement.spacedBy(6.dp)
                    ) {

                        lineas
                            .drop(2)
                            .forEach { linea ->

                                CajonNivelLinea(
                                    linea =
                                        linea,

                                    avance =
                                        avanceLineas[linea],

                                    modifier =
                                        Modifier.weight(1f)
                                )
                            }
                    }
                }
            }
        }


        Spacer(
            modifier = Modifier.height(20.dp)
        )


        // ============================================================
        // INFORMACIÓN DE LA LÍNEA PROFESIONAL
        // ============================================================

        otraLineaSeleccionada?.let { linea ->

            Card(
                modifier =
                    Modifier.fillMaxWidth(),

                elevation =
                    CardDefaults.cardElevation(
                        defaultElevation = 3.dp
                    )
            ) {

                Column(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                ) {

                    // =================================================
                    // TÍTULO
                    // =================================================

                    Text(
                        text =
                            "Línea profesional: $linea",

                        style =
                            MaterialTheme
                                .typography
                                .titleSmall,

                        fontWeight =
                            FontWeight.Bold,

                        textAlign =
                            TextAlign.Center,

                        modifier =
                            Modifier.fillMaxWidth()
                    )


                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )


                    // =================================================
                    // BOTONES DE SELECCIÓN
                    // =================================================

                    Column(
                        modifier =
                            Modifier.fillMaxWidth(),

                        horizontalAlignment =
                            Alignment.CenterHorizontally
                    ) {

                        // =============================================
                        // PRIMERA FILA
                        // =============================================

                        Row(
                            horizontalArrangement =
                                Arrangement.Center,

                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {

                            listOf(
                                "Educativa",
                                "Social",
                                "Organizacional"
                            ).forEach { lineaSeleccionable ->

                                FilterChip(
                                    selected =
                                        otraLineaSeleccionada ==
                                                lineaSeleccionable,

                                    onClick = {
                                        otraLineaSeleccionada =
                                            lineaSeleccionable
                                    },

                                    label = {
                                        Text(
                                            text =
                                                lineaSeleccionable
                                        )
                                    },

                                    modifier =
                                        Modifier.padding(
                                            horizontal = 3.dp
                                        )
                                )
                            }
                        }


                        // =============================================
                        // SEGUNDA FILA
                        // =============================================

                        Row(
                            horizontalArrangement =
                                Arrangement.Center,

                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {

                            listOf(
                                "Clínica",
                                "NeuroClínica"
                            ).forEach { lineaSeleccionable ->

                                FilterChip(
                                    selected =
                                        otraLineaSeleccionada ==
                                                lineaSeleccionable,

                                    onClick = {
                                        otraLineaSeleccionada =
                                            lineaSeleccionable
                                    },

                                    label = {
                                        Text(
                                            text =
                                                lineaSeleccionable
                                        )
                                    },

                                    modifier =
                                        Modifier.padding(
                                            horizontal = 3.dp
                                        )
                                )
                            }
                        }
                    }


                    Spacer(
                        modifier = Modifier.height(10.dp)
                    )


                    HorizontalDivider()


                    Spacer(
                        modifier = Modifier.height(10.dp)
                    )


                    // =================================================
                    // MÓDULOS DE LA LÍNEA
                    // =================================================

                    val materiasLinea =
                        programa
                            .estudiante
                            ?.asignaturas
                            ?.filter {
                                it.lineaProfesional == linea
                            }
                            .orEmpty()


                    if (materiasLinea.isEmpty()) {

                        Text(
                            text =
                                "No hay módulos registrados para esta línea todavía.",

                            style =
                                MaterialTheme
                                    .typography
                                    .bodyMedium,

                            color =
                                MaterialTheme
                                    .colorScheme
                                    .onSurfaceVariant,

                            modifier =
                                Modifier.fillMaxWidth()
                        )

                    } else {

                        // =================================================
                        // MÓDULOS AUTOAJUSTADOS
                        // =================================================

                        Row(
                            modifier =
                                Modifier.fillMaxWidth(),

                            horizontalArrangement =
                                Arrangement.spacedBy(5.dp),

                            verticalAlignment =
                                Alignment.Top
                        ) {

                            materiasLinea
                                .take(3)
                                .forEachIndexed { indice, materia ->

                                    val nivel =
                                        when (indice) {

                                            0 ->
                                                "Nivel I"

                                            1 ->
                                                "Nivel II"

                                            2 ->
                                                "Nivel III"

                                            else ->
                                                "Nivel ${indice + 1}"
                                        }


                                    val colorTarjeta =
                                        MaterialTheme
                                            .colorScheme
                                            .surfaceContainerLow


                                    val colorEncabezado =
                                        MaterialTheme
                                            .colorScheme
                                            .secondaryContainer


                                    val colorTextoEncabezado =
                                        MaterialTheme
                                            .colorScheme
                                            .onSecondaryContainer


                                    val colorTextoSecundario =
                                        MaterialTheme
                                            .colorScheme
                                            .onSurfaceVariant


                                    val colorNota =
                                        if (materia.aprobo()) {

                                            MaterialTheme
                                                .colorScheme
                                                .tertiary

                                        } else {

                                            colorTextoSecundario
                                        }


                                    // =====================================
                                    // CARD DEL NIVEL
                                    // =====================================

                                    Card(
                                        modifier =
                                            Modifier.weight(1f),

                                        shape =
                                            MaterialTheme
                                                .shapes
                                                .medium,

                                        elevation =
                                            CardDefaults
                                                .cardElevation(
                                                    defaultElevation =
                                                        1.dp
                                                ),

                                        border =
                                            BorderStroke(
                                                width = 0.7.dp,

                                                color =
                                                    MaterialTheme
                                                        .colorScheme
                                                        .outlineVariant
                                            ),

                                        colors =
                                            CardDefaults
                                                .cardColors(
                                                    containerColor =
                                                        colorTarjeta
                                                )
                                    ) {

                                        Column(
                                            modifier =
                                                Modifier.fillMaxWidth()
                                        ) {

                                            // =========================
                                            // NIVEL
                                            // =========================

                                            Surface(
                                                color =
                                                    colorEncabezado,

                                                modifier =
                                                    Modifier.fillMaxWidth()
                                            ) {

                                                Text(
                                                    text =
                                                        nivel,

                                                    style =
                                                        MaterialTheme
                                                            .typography
                                                            .labelMedium,

                                                    fontWeight =
                                                        FontWeight.Bold,

                                                    color =
                                                        colorTextoEncabezado,

                                                    textAlign =
                                                        TextAlign.Center,

                                                    modifier =
                                                        Modifier
                                                            .fillMaxWidth()
                                                            .padding(
                                                                vertical =
                                                                    5.dp
                                                            )
                                                )
                                            }


                                            // =========================
                                            // INFORMACIÓN
                                            // =========================

                                            Column(
                                                modifier =
                                                    Modifier
                                                        .fillMaxWidth()
                                                        .padding(
                                                            horizontal =
                                                                7.dp,

                                                            vertical =
                                                                7.dp
                                                        )
                                            ) {

                                                // =====================
                                                // CRÉDITOS
                                                // =====================

                                                Row(
                                                    modifier =
                                                        Modifier.fillMaxWidth(),

                                                    horizontalArrangement =
                                                        Arrangement.SpaceBetween,

                                                    verticalAlignment =
                                                        Alignment.CenterVertically
                                                ) {

                                                    Text(
                                                        text =
                                                            "Créditos",

                                                        style =
                                                            MaterialTheme
                                                                .typography
                                                                .labelSmall,

                                                        color =
                                                            colorTextoSecundario
                                                    )


                                                    Text(
                                                        text =
                                                            materia
                                                                .creditos
                                                                .toString(),

                                                        style =
                                                            MaterialTheme
                                                                .typography
                                                                .labelMedium,

                                                        fontWeight =
                                                            FontWeight.Bold
                                                    )
                                                }


                                                Spacer(
                                                    modifier =
                                                        Modifier.height(5.dp)
                                                )


                                                HorizontalDivider(
                                                    color =
                                                        MaterialTheme
                                                            .colorScheme
                                                            .outlineVariant,

                                                    thickness =
                                                        0.6.dp
                                                )


                                                Spacer(
                                                    modifier =
                                                        Modifier.height(5.dp)
                                                )


                                                // =====================
                                                // NOTA
                                                // =====================

                                                Row(
                                                    modifier =
                                                        Modifier.fillMaxWidth(),

                                                    horizontalArrangement =
                                                        Arrangement.SpaceBetween,

                                                    verticalAlignment =
                                                        Alignment.CenterVertically
                                                ) {

                                                    Text(
                                                        text =
                                                            "Nota",

                                                        style =
                                                            MaterialTheme
                                                                .typography
                                                                .labelSmall,

                                                        color =
                                                            colorTextoSecundario
                                                    )


                                                    Text(
                                                        text =
                                                            materia.textoNota(),

                                                        style =
                                                            MaterialTheme
                                                                .typography
                                                                .labelMedium,

                                                        fontWeight =
                                                            FontWeight.Bold,

                                                        color =
                                                            colorNota
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                        }
                    }
                }
            }
        }


        Spacer(
            modifier = Modifier.height(16.dp)
        )
    }
}


// ========================================================================
// CAJÓN DE NIVEL DE LÍNEA PROFESIONAL
// ========================================================================

@Composable
private fun CajonNivelLinea(
    linea: String,
    avance: AvanceLineaProfesional?,
    modifier: Modifier = Modifier
) {

    val aprobado =
        avance != null


    val color =
        if (aprobado) {

            Color(0xFF2E7D32)

        } else {

            Color(0xFFC62828)
        }


    val textoNivel =
        if (aprobado) {

            when (avance!!.nivel) {

                1 ->
                    "Nivel I"

                2 ->
                    "Nivel II"

                3 ->
                    "Nivel III"

                else ->
                    "Nivel ${avance.nivel}"
            }

        } else {

            "No cursó"
        }


    Surface(
        modifier =
            modifier.height(58.dp),

        shape =
            MaterialTheme
                .shapes
                .medium,

        color =
            color
    ) {

        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(
                        horizontal = 6.dp,
                        vertical = 4.dp
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Column(
                horizontalAlignment =
                    Alignment.CenterHorizontally
            ) {

                Text(
                    text =
                        linea,

                    color =
                        Color.White,

                    style =
                        MaterialTheme
                            .typography
                            .labelSmall,

                    fontWeight =
                        FontWeight.Bold,

                    textAlign =
                        TextAlign.Center,

                    maxLines =
                        2
                )


                Text(
                    text =
                        textoNivel,

                    color =
                        Color.White,

                    style =
                        MaterialTheme
                            .typography
                            .labelSmall,

                    textAlign =
                        TextAlign.Center
                )
            }
        }
    }
}


// ========================================================================
// CAJÓN DE REQUISITO DE ASIGNATURA
// ========================================================================

@Composable
private fun CajonRequisitoMateria(
    nombre: String,
    cumple: Boolean,
    modifier: Modifier = Modifier
) {

    val color =
        if (cumple) {

            Color(0xFF2E7D32)

        } else {

            Color(0xFFC62828)
        }


    Surface(
        modifier =
            modifier.height(58.dp),

        shape =
            MaterialTheme
                .shapes
                .medium,

        color =
            color
    ) {

        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(
                        horizontal = 8.dp,
                        vertical = 5.dp
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Text(
                text =
                    if (cumple) {
                        "Cursó\n$nombre"
                    } else {
                        "No cursó\n$nombre"
                    },

                color =
                    Color.White,

                style =
                    MaterialTheme
                        .typography
                        .labelSmall,

                fontWeight =
                    FontWeight.SemiBold,

                textAlign =
                    TextAlign.Center,

                maxLines =
                    3
            )
        }
    }
}


// ========================================================================
// INDICADOR DE CRÉDITOS
// ========================================================================

@Composable
private fun IndicadorCreditos(
    titulo: String,
    creditos: Int,
    total: Int
) {

    val creditosSeguros =
        creditos.coerceIn(
            0,
            total
        )


    val progreso =
        if (total > 0) {

            creditosSeguros.toFloat() /
                    total.toFloat()

        } else {

            0f
        }


    val completo =
        creditos >= total


    val colorFondo =
        MaterialTheme
            .colorScheme
            .surfaceVariant


    val colorIndicador =
        if (completo) {

            Color(0xFF2E7D32)

        } else {

            MaterialTheme
                .colorScheme
                .primary
        }


    Column(
        modifier =
            Modifier.width(150.dp),

        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        Text(
            text =
                titulo,

            style =
                MaterialTheme
                    .typography
                    .labelLarge,

            fontWeight =
                FontWeight.SemiBold,

            textAlign =
                TextAlign.Center,

            maxLines =
                2,

            modifier =
                Modifier.fillMaxWidth()
        )


        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(82.dp),

            contentAlignment =
                Alignment.Center
        ) {

            Canvas(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(82.dp)
            ) {

                val grosor =
                    10.dp.toPx()


                val diametro =
                    minOf(
                        size.width * 0.76f,
                        size.height * 2f
                    ) - grosor


                val izquierda =
                    (size.width - diametro) / 2f


                val arriba =
                    size.height -
                            diametro / 2f


                // ====================================================
                // FONDO
                // ====================================================

                drawArc(
                    color =
                        colorFondo,

                    startAngle =
                        180f,

                    sweepAngle =
                        180f,

                    useCenter =
                        false,

                    topLeft =
                        Offset(
                            izquierda,
                            arriba
                        ),

                    size =
                        Size(
                            diametro,
                            diametro
                        ),

                    style =
                        Stroke(
                            width =
                                grosor,

                            cap =
                                StrokeCap.Round
                        )
                )


                // ====================================================
                // PROGRESO
                // ====================================================

                drawArc(
                    color =
                        colorIndicador,

                    startAngle =
                        180f,

                    sweepAngle =
                        180f * progreso,

                    useCenter =
                        false,

                    topLeft =
                        Offset(
                            izquierda,
                            arriba
                        ),

                    size =
                        Size(
                            diametro,
                            diametro
                        ),

                    style =
                        Stroke(
                            width =
                                grosor,

                            cap =
                                StrokeCap.Round
                        )
                )
            }


            Text(
                text =
                    "$creditosSeguros / $total",

                style =
                    MaterialTheme
                        .typography
                        .titleMedium,

                fontWeight =
                    FontWeight.Bold,

                color =
                    colorIndicador,

                modifier =
                    Modifier.padding(
                        top = 23.dp
                    )
            )
        }
    }
}


// ========================================================================
// LÍNEAS FALTANTES
// ========================================================================

private fun obtenerLineasFaltantes(
    programa: ProgramaM
): List<String> {

    val estudiante =
        programa.estudiante
            ?: return emptyList()


    val gruposLinea =
        listOf(
            "Social",
            "Organizacional",
            "Educativa",
            "Clínica/NeuroClínica"
        )


    val lineasCursadas =
        estudiante
            .asignaturas
            .filter {
                it.aprobo()
            }
            .map {
                it.lineaProfesional
            }
            .distinct()
            .toMutableSet()


    // ================================================================
    // CLÍNICA Y NEUROCLÍNICA CUENTAN COMO UNA MISMA LÍNEA
    // ================================================================

    if (
        lineasCursadas.contains("Clínica") ||
        lineasCursadas.contains("NeuroClínica")
    ) {

        lineasCursadas.remove(
            "Clínica"
        )

        lineasCursadas.remove(
            "NeuroClínica"
        )

        lineasCursadas.add(
            "Clínica/NeuroClínica"
        )
    }


    return gruposLinea.filter {
        it !in lineasCursadas
    }
}