package com.renea.psicologiauv.gui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.renea.psicologiauv.R
import com.renea.psicologiauv.data.Serializador
import com.renea.psicologiauv.ui.theme.PsicologiaUVTheme


class MainActivity : ComponentActivity() {

    private val viewModel: ControlV by viewModels {
        ControlV.Factory(
            Serializador(applicationContext)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            PsicologiaUVTheme {
                Surface {
                    PsicologiaUVApp(viewModel)
                }
            }
        }
    }
}


/* ---------------------------------------------------------------------- */
/* PANTALLAS DE LA APP                                                    */
/* ---------------------------------------------------------------------- */

enum class PantallasApp(
    val leyenda: String,
    val icono: Int
) {

    USUARIO(
        "Usuario",
        R.drawable.ic_avatar_default
    ),

    PENSUM(
        "Pensum",
        R.drawable.ic_home
    ),

    GRADO(
        "Grado",
        R.drawable.ic_documento
    ),

    AVANCE(
        "Avance",
        R.drawable.ic_favorite
    ),

    REQUISITOS(
        "Requisitos",
        R.drawable.ic_favorite
    )
}


/* ---------------------------------------------------------------------- */
/* APP PRINCIPAL                                                          */
/* ---------------------------------------------------------------------- */

@Composable
fun PsicologiaUVApp(
    viewModel: ControlV
) {

    /*
     * RememberSaveable recuerda qué pestaña estaba seleccionada
     * aunque el usuario rote la pantalla o la app pase a segundo plano.
     */
    var destinoActual by rememberSaveable {
        mutableStateOf(
            if (viewModel.primeraVezQueAbreLaApp) PantallasApp.USUARIO
            else PantallasApp.AVANCE
        )
    }


    /*
     * La pestaña "Grado" SOLO debe estar visible cuando el estudiante ya
     * cumple todos los requisitos para graduarse. Si en algún momento deja
     * de cumplirlos (por ejemplo, se elimina una asignatura complementaria)
     * mientras esa pestaña está seleccionada, se redirige a "Avance" para
     * no dejar al usuario viendo una pantalla a la que ya no debería tener
     * acceso.
     */
    val cumpleRequisitosGrado =
        viewModel.programa.cumpleRequisitosGrado()

    LaunchedEffect(cumpleRequisitosGrado) {
        if (destinoActual == PantallasApp.GRADO && !cumpleRequisitosGrado) {
            destinoActual = PantallasApp.AVANCE
        }
    }


    Scaffold(

        bottomBar = {

            NavigationBar(
                modifier = Modifier.height(80.dp)
            ) {

                PantallasApp.entries
                    .filter {
                        it != PantallasApp.GRADO || cumpleRequisitosGrado
                    }
                    .forEach { destino ->

                        NavigationBarItem(

                            selected =
                                destino == destinoActual,

                            onClick = {
                                destinoActual = destino
                            },

                            icon = {

                                Icon(
                                    painter =
                                        painterResource(
                                            destino.icono
                                        ),

                                    contentDescription =
                                        destino.leyenda,

                                    modifier =
                                        Modifier.size(18.dp)
                                )
                            },

                            label = {

                                Text(
                                    text =
                                        destino.leyenda,

                                    fontSize =
                                        9.sp
                                )
                            }
                        )
                    }
            }
        }

    ) { paddingInterno ->

        val estudiante =
            viewModel.programa.estudiante


        /*
         * Si no existe estudiante, no podemos mostrar
         * las pantallas que dependen de sus datos.
         */

        if (estudiante == null) {

            Text(
                text =
                    "No se pudo cargar la información del estudiante.",

                modifier =
                    Modifier.padding(
                        paddingInterno
                    )
            )

            return@Scaffold
        }


        /*
         * Aquí decidimos qué pantalla mostrar
         * dependiendo de la pestaña seleccionada.
         */

        when (destinoActual) {


            // ==========================================================
            // USUARIO
            // ==========================================================

            PantallasApp.USUARIO -> {

                PantallaEditar(
                    modifier =
                        Modifier.padding(
                            paddingInterno
                        ),

                    viewModel =
                        viewModel
                )
            }


            // ==========================================================
            // PENSUM
            // ==========================================================

            PantallasApp.PENSUM -> {

                PantallaPensum(
                    modifier =
                        Modifier.padding(
                            paddingInterno
                        ),

                    estudiante =
                        estudiante,

                    viewModel =
                        viewModel
                )
            }


            // ==========================================================
            // GRADO
            // ==========================================================

            PantallasApp.GRADO -> {

                PantallaGrado(
                    modifier =
                        Modifier.padding(
                            paddingInterno
                        ),

                    programa =
                        viewModel.programa
                )
            }


            // ==========================================================
            // AVANCE
            // ==========================================================

            PantallasApp.AVANCE -> {

                PantallaAvance(
                    modifier =
                        Modifier.padding(
                            paddingInterno
                        ),

                    programa =
                        viewModel.programa
                )
            }


            // ==========================================================
            // REQUISITOS
            // ==========================================================

            PantallasApp.REQUISITOS -> {

                PantallaRequisitos(
                    modifier =
                        Modifier.padding(
                            paddingInterno
                        ),

                    programa =
                        viewModel.programa
                )
            }
        }
    }
}